public class TryAndCatchTest{
    public static void main (String[] args){
        TryAndCatch block = new TryAndCatch();
        block.testList();
    }
}