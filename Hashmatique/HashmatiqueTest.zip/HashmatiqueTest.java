public class HashmatiqueTest {
    public static void main (String [] args){
        Hashmatique result = new Hashmatique();
        result.trackList();
    }
}