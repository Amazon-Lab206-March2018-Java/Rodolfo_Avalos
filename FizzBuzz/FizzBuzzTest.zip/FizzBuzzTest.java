public class FizzBuzzTest {
    public static void main(String[] args){
        FizzBuzz result = new FizzBuzz();
        System.out.println(result.fizzBuzz(13));
        System.out.println(result.fizzBuzz(15));
        System.out.println(result.fizzBuzz(20));
        System.out.println(result.fizzBuzz(21));
    }
}