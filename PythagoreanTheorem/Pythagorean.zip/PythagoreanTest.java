public class PythagoreanTest {
    public static void main(String[] args){
        Pythagorean solution = new Pythagorean();
        System.out.println(solution.calculateHypotenuse(3,4));
    }
}