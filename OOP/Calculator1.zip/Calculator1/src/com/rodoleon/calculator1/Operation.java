package com.rodoleon.calculator1;

public interface Operation {
	void performOperation();
	double getResults();
}
