package com.rodoleon.ObjectMaster;

public class HumanTest {

	public static void main(String[] args) {
		Human Dummy1 = new Human();
		Human Dummy2 = new Human();
		Dummy1.showStats();
		Dummy2.attackHuman(Dummy1);
		Dummy2.attackHuman(Dummy1);
		Dummy1.showStats();
	}
}
