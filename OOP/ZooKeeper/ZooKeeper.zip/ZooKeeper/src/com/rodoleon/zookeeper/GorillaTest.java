package com.rodoleon.zookeeper;

public class GorillaTest {

	public static void main(String[] args) {
		Gorilla Al = new Gorilla();
		Al.throwSomething();
		Al.throwSomething();
		Al.throwSomething();
		Al.eatBananas();
		Al.eatBananas();
		Al.climb();
		Al.displayEnergyLevel();
	}
}
