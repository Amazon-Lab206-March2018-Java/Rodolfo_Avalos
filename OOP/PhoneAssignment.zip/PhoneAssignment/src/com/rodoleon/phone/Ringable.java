package com.rodoleon.phone;

public interface Ringable {
	public String ring();
	public String unlock();
}
