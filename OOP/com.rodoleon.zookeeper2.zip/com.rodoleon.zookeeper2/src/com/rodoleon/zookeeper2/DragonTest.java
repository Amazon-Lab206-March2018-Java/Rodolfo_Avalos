package com.rodoleon.zookeeper2;

public class DragonTest {
	public static void main(String[] args) {
		Dragon Fire = new Dragon();
		Fire.attackTown();
		Fire.attackTown();
		Fire.displayEnergyLevel();
		Fire.attackTown();
		Fire.displayEnergyLevel();
		Fire.eatHumans();
		Fire.eatHumans();
		Fire.displayEnergyLevel();
		Fire.fly();
		Fire.fly();
		Fire.displayEnergyLevel();
		}
}
