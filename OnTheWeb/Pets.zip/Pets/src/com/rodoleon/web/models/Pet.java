package com.rodoleon.web.models;

public interface Pet {
	String showAffection();
}
